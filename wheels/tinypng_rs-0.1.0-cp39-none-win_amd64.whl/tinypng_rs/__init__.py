from .tinypng_rs import *

__doc__ = tinypng_rs.__doc__
if hasattr(tinypng_rs, "__all__"):
    __all__ = tinypng_rs.__all__